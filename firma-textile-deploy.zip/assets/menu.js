// Minimal, no third-party code. Mobile menu + contact form (mailto compose).
(function () {
  // --- Mobile menu ---
  var btn = document.querySelector('.nav-toggle');
  var menu = document.getElementById('menu');
  if (btn && menu) {
    btn.addEventListener('click', function () {
      var open = menu.classList.toggle('open');
      btn.setAttribute('aria-expanded', open);
    });
    menu.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') {
        menu.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // --- Contact form ---
  // Default: opens the visitor's email app addressed to hello@firmatextile.com.
  // No data leaves the page to any third party. To handle submissions server-side
  // instead, give the <form> an action/method and POST these fields to your endpoint.
  var form = document.querySelector('.c-form');
  if (form) {
    var note = form.querySelector('.form-note');
    var val = function (id) {
      var el = document.getElementById(id);
      return el ? el.value.trim() : '';
    };
    var show = function (msg, ok) {
      note.hidden = false;
      note.textContent = msg;
      note.className = 'form-note ' + (ok ? 'ok' : 'err');
    };
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = val('cf-name'), email = val('cf-email'),
          company = val('cf-company'), message = val('cf-message');
      var consent = document.getElementById('cf-consent');
      var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      if (!name || !email || !message) {
        show('Please add your name, email, and a message.', false); return;
      }
      if (!emailOk) { show('Please check your email address.', false); return; }
      if (consent && !consent.checked) {
        show('Please tick the consent box so we can reply.', false); return;
      }
      var subject = 'Website enquiry from ' + name + (company ? ' (' + company + ')' : '');
      var body = 'Name: ' + name + '\nEmail: ' + email +
                 (company ? '\nCompany: ' + company : '') + '\n\n' + message;
      window.location.href = 'mailto:hello@firmatextile.com?subject=' +
        encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
      show('Opening your email app to send the message\u2026', true);
    });
  }
})();
